<?php
	$servername="localhost";
	$hostname="root";

	$pass="";

	$conn=mysql_connect("$servername","$hostname","$pass");
	

	mysql_select_db('college_ecommerce');

?>