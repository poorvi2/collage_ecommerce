<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
	<!-- //for bootstrap working -->
	
	
	<!-- navigation -->
	<div class="navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header nav_2">
					<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div> 
				<div class="col-md-4 w3l_logo">
					<h1><a href="index.php">Best Price<span>Your stores. Your place.</span></a></h1>
				</div>
				<div class="col-md-8 collapse navbar-collapse" id="bs-megadropdown-tabs">
					<ul class="nav navbar-nav">
						<li><a href="index.php " class="<?php if($active =='index'){echo 'act';}?>">Home</a></li>
						<li><a href="about.php " class="<?php if($active =='about'){echo 'act';}?>">About Us</a></li>
						<li><a href="products.php " class="<?php if($active =='products'){echo 'act';}?>">Products</a></li>
						<li><a href="contact.php " class="<?php if($active =='contact'){echo 'act';}?>">Contact</a></li>
						

						
						
					</ul>
				</div>
			</nav>
		</div>
	</div>
	<br>
	<!-- //navigation -->