<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_footer_grids">
				<div class="col-md-4 w3_footer_grid">
					<h3>Contact</h3>
					<p>Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
					<ul class="address">
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Bhilai, <span>Chhattisgarh.</span></li>
						
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>(+91) 77798 77428
</li>
					</ul>
				</div>
				
				<div class="col-md-4 w3_footer_grid">
					<h3>Category</h3>
					<ul class="info"> 
						<li><a href="products.php">Mobiles</a></li>
						<li><a href="products.php">Laptops</a></li>
						<li><a href="products.php">Led</a></li>
						<li><a href="products.php">Gadgets</a></li>
						<li><a href="products.php">Camera</a></li>
					</ul>
				</div>
				<div class="col-md-4 w3_footer_grid">
					<h3>Stores</h3>
					<ul class="info"> 
						
						<li><a href="#">Flipkart</a></li>
						<li><a href="#">Snapdeal</a></li>
						<li><a href="#">Amazon</a></li>
						<li><a href="#">Myntra</a></li>
					</ul>
					
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="footer-copy">
			<div class="footer-copy1">
				<div class="footer-copy-pos">
					<a href="#home1" class="scroll"><img src="images/arrow.png" alt=" " class="img-responsive" /></a>
				</div>
			</div>
			<div class="container">
				<p>&copy; 2018 Best Price . All rights reserved |</a></p>
			</div>
		</div>
	</div>
	<!-- //footer --> 
	<!-- cart-js -->
	
	
</body>
</html>